from django.shortcuts import render, redirect
from . import forms
import datetime


def deletecondition(request, id):

    patient = Patient.objects.get(id=id)
    patient.delete()

    return redirect('condition_details')
          

def view_condition(request):
    con = Condition.objects.all()
    c= {'con': con}
    return render (request, "condition_details.html", c)

def add_condition(request):
    if request.method == 'POST' :
        condtionname = request.POST['first name']
        severity= request.POST['severity']
        start_date = request.POST['start_date']
        end_date = request.POST['end_date']
        
        
    return render(request , 'add_condition.html',d)



def delete_confirm(request, id):
    return render(request, "delete.html", {
        'id': id,
    })