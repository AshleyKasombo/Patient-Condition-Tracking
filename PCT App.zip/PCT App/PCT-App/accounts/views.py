from django.shortcuts import render, redirect
from django.contrib.auth.forms import UserCreationForm, AuthenticationForm
from django.contrib.auth import login, logout


# Create your views here.
def signup_view(request):
    if request.method == 'POST':
        form = UserCreationForm(request.POST)
        if form.is_valid():
            user = form.save()
            login(request, user)
            return redirect('homepage')
    else:
        form = UserCreationForm()
    return render(request, 'accounts/signup.html', {'form': form})


def login_view(request):
    if request.method == 'POST':
        form = AuthenticationForm(data=request.POST)
        if form.is_valid():
            user = form.get_user()
            login(request, user)
            if 'next' in request.POST:
                return redirect(request.POST.get('next'))
            else:
                return redirect('homepage')
    else:
        form = AuthenticationForm()
    return render(request, 'accounts/login.html', {'form': form})


def logout_view(request):
    if request.method == 'POST':
        logout(request)
        return redirect('homepage')

def deletepatient(request, id):

    patient = Patient.objects.get(id=id)
    patient.delete()

    return redirect('patient_details')
          

def view_patients(request):
    pat = Patient.objects.all()
    p = {'pat': pat}
    return render (request, "patient_details.html", p)

def add_patients(request):
    if request.method == 'POST' :
        fname = request.POST['first name']
        lname = request.POST['last name']
        phone = request.POST['Phone']
        age = request.POST['age']
        gender =  request.POST['gender']
        condition = request.POST['condition']

        try:
            Patient.objects.create(firstname =fname, lastname = lname, phone= phone, age = age,condition = condition )
            error ="no"
        except:
            error = "yes"
    d = {'error': error}
    return render(request , 'add_patients.html',d)



def delete_confirm(request, id):
    return render(request, "delete.html", {
        'id': id,
    })
