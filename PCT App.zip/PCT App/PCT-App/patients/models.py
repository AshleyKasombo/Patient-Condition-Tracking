from django.db import models
from django.contrib.auth.models import User


GENDER_CHOICES = (
    (1, 'Female'),
    (2, 'Male'),
    (3, 'Other'),
    )

class Patient(models.Model):
    first_name = models.CharField(max_length=30, blank=False)
    last_name = models.CharField(max_length=60, blank=False)
    id_no = models.SlugField(max_length=11, blank=False, unique=True)
    phone = models.CharField(max_length=12, blank=True)
    photo = models.ImageField(default='default_patient_img.png', blank=True)
    age =models.IntegerField(blank = False)
    gender = models.PositiveSmallIntegerField(
        choices=GENDER_CHOICES, default=3)
    condition = models.ForeignKey(User, default=None, on_delete=models.CASCADE, )

    def __str__(self):
        return "{} {}   ({})".format(self.last_name, self.first_name, self.id_no)
