from django.db import models
from django.contrib.auth.models import User
from patients.models import Patient
import datetime
from django.template.defaultfilters import slugify

SEVERITY = (
    (0, 'New'),
    (1, 'Average'),
    (2, 'Severe'),
    (3, 'Very Severe'),
)

# Create your models here.
class Condition(models.Model):
    condition_name = models.CharField(" Condition Name", max_length=50, null=False, blank=False, help_text="Condition Name")
    severity = models.CharField("Condition Severity", max_length=20, null=True, blank=False, help_text='Condition Severity', choices= SEVERITY)
    start_date = models.DateField("Condition Startdate", help_text="Condition Start date")
    end_date =models.DateField("Condition enddate", help_text="Condition End date")

    

    def __str__(self):
        return "{} {} {}".format(self.condition_name)



