from django import forms
from . import models


class PatientAddForm(forms.ModelForm):
    class Meta:
        model = models.Patient
        fields = ['first_name', 'last_name', 'id_no', 'phone', 'age', 'photo', 'condition' , 'gender']
